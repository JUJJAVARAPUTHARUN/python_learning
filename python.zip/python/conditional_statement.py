wallet = 130
movie_1 = 180
movie_2 = 140
if movie_1 <= wallet: 
    print('Go Movie')
elif wallet > movie_2:
    print('Go Movie2')
else:
    print('no money')
print("Hello Tharun")

print(100+20+10);

x,y,z = 1,2,3
print(x)
print(y)
print(z)

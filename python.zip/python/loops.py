for i in range(20):
    if(i%2 == 0):
        print('Number is Even',i)
    else:
        print('Number is not even',i)

#while
i=0
while i < 10:
    print(i)
    i +=2